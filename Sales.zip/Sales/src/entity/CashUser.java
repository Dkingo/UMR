package entity;

public class CashUser {
	
	private String cash_username;
	private String cash_password;
	
	public String getCash_username() {
		return cash_username;
	}
	
	public void setCash_username(String cash_username) {
		this.cash_username = cash_username;
	}
	
	public String getCash_password() {
		return cash_password;
	}
	
	public void setCash_password(String cash_password) {
		this.cash_password = cash_password;
	}	
	
}
