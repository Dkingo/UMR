package entity;

public class Manager {
	
	private String mag_username;
	private String mag_password;
	
	public String getMag_username() {
		return mag_username;
	}
	
	public void setMag_username(String mag_username) {
		this.mag_username = mag_username;
	}
	
	public String getMag_password() {
		return mag_password;
	}
	
	public void setMag_password(String mag_password) {
		this.mag_password = mag_password;
	}
	
}
